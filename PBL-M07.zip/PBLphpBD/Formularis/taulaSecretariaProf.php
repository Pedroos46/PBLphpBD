<?php
echo '<table class="mdl-data-table mdl-js-data-table mdl-data-table--selectable mdl-shadow--2dp">';
    echo '<thead>';
        echo '<tr>';
            echo '<th>ID</th>';
            echo '<th>DNI Profesor</th>';
            echo '<th>Nom</th>';
            echo '<th>Asignatura</th>';
            echo '<th>Contrasenya</th>';
        echo '</tr>';
    echo '</thead>';
echo '<tbody>';
?>