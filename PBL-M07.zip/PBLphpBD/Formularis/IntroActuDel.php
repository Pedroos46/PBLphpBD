<?php
echo '<label class="mdl-radio mdl-js-radio mdl-js-ripple-effect" for="option-1">';
echo '<input type="radio" id="option-1" class="mdl-radio__button" name="options" value="Introduir">';
echo '<span class="mdl-radio__label">Introduir</span>';
echo '</label>';

echo '<label class="mdl-radio mdl-js-radio mdl-js-ripple-effect" for="option-2">';
echo '<input type="radio" id="option-2" class="mdl-radio__button" name="options" value="Actualitzar">';
echo '<span class="mdl-radio__label">Actualitza</span>';
echo '</label>';

echo '<label class="mdl-radio mdl-js-radio mdl-js-ripple-effect" for="option-3">';
echo '<input type="radio" id="option-3" class="mdl-radio__button" name="options" value="Eliminar">';
echo '<span class="mdl-radio__label">Eliminar</span>';
echo '</label>';
?>