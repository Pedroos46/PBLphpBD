<?php
echo '<table class="mdl-data-table mdl-js-data-table mdl-data-table--selectable mdl-shadow--2dp">';
    echo '<thead>';
        echo '<tr>';
            echo '<th>DNI alumne</th>';
            echo '<th>Asignatura</th>';
            echo '<th>Nota</th>';
            echo '<th>Curs</th>';
        echo '</tr>';
    echo '</thead>';
echo '<tbody>';
?>